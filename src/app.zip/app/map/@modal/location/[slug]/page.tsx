'use client';

import { useRouter } from 'next/navigation';

export const dynamic = 'force-dynamic';

export default function LocationModal({ params }) {
  const router = useRouter();

  return (
    <div style={{
      position: 'fixed',
      top: 0,
      left: 0,
      width: '100vw',
      height: '100vh',
      background: 'white',
      zIndex: 1000,
      padding: '2rem'
    }}>
      <button onClick={() => router.back()}>Back</button>
      <h1>Overlay for: {params.slug}</h1>
    </div>
  );
}
