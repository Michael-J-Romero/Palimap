"use client";
import React from 'react';
export default function Page() {
    return <div>Community Page</div>;
}  // Placeholder for page.tsx