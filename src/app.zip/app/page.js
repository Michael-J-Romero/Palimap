"use client";

import React from "react";
import {
  Box,
  Typography,
  Button,
  Container,
  Grid,
  Card,
  CardContent,
  CardMedia,
  Divider,
} from "@mui/material";
import { useTheme } from "@mui/material/styles";
import MapIcon from "@mui/icons-material/Map";
import AddCircleOutlineIcon from "@mui/icons-material/AddCircleOutline";
import TrendingUpIcon from "@mui/icons-material/TrendingUp";

const HomepageBody = () => {
  const theme = useTheme();

  return (
    <Container maxWidth="lg" sx={{ py: { xs: 4, md: 6 } }}>
      {/* Hero Section */}
      <Box textAlign="center" mb={6}>
        <Typography variant="h3" fontWeight="bold" gutterBottom>
          Rebuilding Together
        </Typography>
        <Typography variant="h6" color="text.secondary" maxWidth="md" mx="auto">
          Your interactive hub for fire recovery — see updates, share progress,
          and support your community.
        </Typography>
        <Box mt={4} display="flex" justifyContent="center" gap={2}>
          <Button variant="contained" size="large" startIcon={<MapIcon />}>
            View the Map
          </Button>
          <Button variant="outlined" size="large" startIcon={<AddCircleOutlineIcon />}>
            Post an Update
          </Button>
        </Box>
      </Box>

      {/* How it works */}
      <Grid container spacing={4} mb={6}>
        {[
          {
            title: "Explore the Map",
            desc: "See real-time updates from your neighbors — from reconstruction to reopening.",
          },
          {
            title: "Share What You See",
            desc: "Post local recovery efforts, events, or alerts with a simple form.",
          },
          {
            title: "Stay Connected",
            desc: "Follow what’s happening around you and get involved where it matters most.",
          },
        ].map((step, i) => (
          <Grid item xs={12} md={4} key={i}>
            <Card elevation={1} sx={{ height: "100%" }}>
              <CardContent>
                <Typography variant="h6" fontWeight={600} gutterBottom>
                  {step.title}
                </Typography>
                <Typography variant="body2" color="text.secondary">
                  {step.desc}
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Live Stats Placeholder */}
      <Box mb={6}>
        <Typography variant="h5" fontWeight="bold" gutterBottom>
          This Week’s Highlights
        </Typography>
        <Typography variant="body2" color="text.secondary" mb={2}>
          14 new posts • 3 new business reopenings • 1 safety alert
        </Typography>
        <Divider />
      </Box>

      {/* Recent Activity Feed (placeholder) */}
      <Grid container spacing={4} mb={6}>
        {[1, 2, 3].map((_, i) => (
          <Grid item xs={12} md={4} key={i}>
            <Card>
              <CardMedia
                component="div"
                sx={{ height: 160, backgroundColor: theme.palette.grey[300] }}
              >
                {/* Placeholder image */}
              </CardMedia>
              <CardContent>
                <Typography variant="subtitle1" fontWeight={600}>
                  Sample Post Title #{i + 1}
                </Typography>
                <Typography variant="caption" color="text.secondary">
                  Fire Recovery • 2 days ago
                </Typography>
                <Typography
                  variant="body2"
                  color="text.secondary"
                  sx={{ mt: 1, overflow: "hidden", display: "-webkit-box", WebkitLineClamp: 2, WebkitBoxOrient: "vertical" }}
                >
                  Placeholder description text for the post. This should summarize what’s happening and why it matters.
                </Typography>
              </CardContent>
            </Card>
          </Grid>
        ))}
      </Grid>

      {/* Closing Call to Action */}
      <Box textAlign="center">
        <Typography variant="h6" gutterBottom>
          This map is powered by the people who live here.
        </Typography>
        <Button variant="contained" size="large" startIcon={<TrendingUpIcon />}
          sx={{ mt: 2 }}>
          Contribute an Update
        </Button>
      </Box>
    </Container>
  );
};

export default HomepageBody;